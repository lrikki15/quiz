module.exports = require('../virtual-fs').default;
